GESTION PVC - PROJET ANDROID

Le projet contient l'application Android et une automatisation gratuite de compilation APK via GitHub Actions.

COMPILATION DEPUIS UN TÉLÉPHONE ANDROID (sans Android Studio) :
1. Extraire ce ZIP sur le téléphone ou conserver le ZIP pour le téléverser sur GitHub.
2. Sur github.com, créer un nouveau dépôt (repository), par exemple GestionPVC.
3. Téléverser le CONTENU du dossier GestionPVC-Android dans le dépôt, à la racine (le dossier .github doit être inclus).
4. Ouvrir l'onglet Actions du dépôt.
5. Autoriser les GitHub Actions si GitHub le demande.
6. Lancer "Build Gestion PVC APK" avec "Run workflow". Un push sur main lance aussi automatiquement la compilation.
7. Quand le travail est terminé (vert), ouvrir l'exécution et télécharger l'artefact "GestionPVC-debug-apk".
8. Décompresser l'artefact et installer app-debug.apk sur le téléphone. Android peut demander d'autoriser l'installation depuis cette source.

Le dépôt GitHub peut rester privé. Les quotas et conditions gratuits de GitHub Actions peuvent évoluer.

L'application fonctionne hors ligne et conserve les données sur le téléphone (stockage local). Elle ne synchronise pas les téléphones.

IMPORTANT : les coefficients théoriques sont modifiables dans Paramètres. Les valeurs visibles dans le modèle graphique ne sont pas utilisées comme données réelles. Vérifier les coefficients et stocks avant utilisation en production.
